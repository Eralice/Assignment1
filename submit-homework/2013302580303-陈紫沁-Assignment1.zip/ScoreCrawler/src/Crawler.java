import java.io.File;

public class Crawler {
	
	public static void main(String[] args)
	{
		String myurl = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Mon%20Sep%2028%202015%2017:04:47%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
		
		HttpRequest score = HttpRequest.get(myurl);
		
		score.header("cookie","JSESSIONID=9239507B91803DDCDFFE223C38DC49B5.tomcat2");
		
		//�ҵ��Լ��ɼ�����cookie
		
		if(score.ok())
		{
			score.receive(new File("MyScore.html")); 
		}
	}

}


